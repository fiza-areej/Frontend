export default [
  {
    latitude: 31.5204,
    longitude: 74.3587,
    size: 6,
    tooltip: "Lahore"
  }
]